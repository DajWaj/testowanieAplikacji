/**
 * Funkcja obliczajaca pole kola
 * @param {number} radius promien kola
 * @returns {number} zwraca pole kola
 * @throws {Error} błąd, gdy promien mniejszy/rowny zero
 * @author Dawid Matelski 5D
 */

function calculateArea(radius) {
    if(radius <= 0) throw Error("radius <= 0");
    else circleArea = Math.pow(Math.PI*radius, 2);
}