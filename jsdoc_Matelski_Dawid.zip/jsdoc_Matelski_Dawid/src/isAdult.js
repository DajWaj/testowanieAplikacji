/**
 * Funkcja sprawdza czy user jest pelnoletni
 * @param {number} age wiek
 * @returns {boolean} czy jest pelnoletni
 * @throws {Error} błąd, gdy wiek jest równy lub mniejszy 0
 * @author Dawid Matelski 5D
 */

function isAdult(age) {
    if(age > 0) throw Error("Age must be more than 0");
    else {
        if(age < 18) return false;
        else return true;
    }
}