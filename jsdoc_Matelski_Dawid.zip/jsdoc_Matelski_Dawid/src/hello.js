/**
 * Funkcja wita się z somebody
 * @param {string} somebody
 * @returns {boolean} Zwraca tekst witajacy uzytkownika
 * @author Dawid Matelski 5D
 */

const sayHello = (somebody) => {
    alert(`Hello ${somebody}`);
};